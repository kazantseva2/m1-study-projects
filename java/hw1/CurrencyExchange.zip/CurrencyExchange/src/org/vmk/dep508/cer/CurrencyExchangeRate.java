package org.vmk.dep508.cer;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.math.BigDecimal;
import java.util.Currency;

/**
 * Created by VPerov on 17.09.2018.
 */
public class CurrencyExchangeRate {

    public CurrencyExchangeRate(BigDecimal rate, Currency from, Currency to) {
        //TODO: implement
    }

    public Money convert(Money m) {
        throw new NotImplementedException();
    }
}
