package org.vmk.dep508.collections.library;

public class Book {
    int id;
    String title;
}
