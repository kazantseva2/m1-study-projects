CREATE TABLE ABONENTS(
    student_id int,
    student_name varchar(255)
);

CREATE TABLE BOOKS(
    book_id int,
    book_title varchar(255),
    student_id int
);