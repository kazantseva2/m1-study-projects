package org.vmk.dep508.library;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class LibraryTest {
    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void addNewBook() throws Exception {
    }

    @Test
    public void addAbonent() throws Exception {
    }

    @Test
    public void borrowBook() throws Exception {
    }

    @Test
    public void returnBook() throws Exception {
    }

    @Test
    public void findAvailableBooks() throws Exception {
    }

    @Test
    public void getAllStudents() throws Exception {
    }

}