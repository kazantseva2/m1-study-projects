package org.vmk.dep508.io.rest;

public enum HttpMethod {
    GET, POST, DELETE
}
